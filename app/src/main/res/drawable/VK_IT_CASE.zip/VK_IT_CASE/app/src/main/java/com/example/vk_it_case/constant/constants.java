package com.example.vk_it_case.constant;

public class constants {
    public static int c = 0;
    public static int mic = 0;
    public static int revers = 0;
}
